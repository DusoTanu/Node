const { Router } = require("express");
const express = require("express");
const router = express.Router();
const auth = require('../Middleware/auth');

const userController = require('../Countroller/userController');


router.post('/register', userController.register);
router.post('/login', userController.login);
router.get('/getAll', auth.authenticate, userController.getAll);


module.exports = router;