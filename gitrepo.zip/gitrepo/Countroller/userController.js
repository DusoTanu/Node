const express = require('express');
const router = express.Router();
const userService = require('../Service/userService')

// routes
router.post('/register', register);
router.post('/login', login);
router.get('/getAll', getAll);


module.exports = router;

function register(req, res, next) {
    userService.create(req.body)
        .then(message => message ? res.status(400).json({ message: 'Email Is Used!' }) : res.status(200).json({ message: 'Successfully Data Inserted' }))
        .catch(err => next(err));
}

function login(req, res, next) {
    userService.auth(req.body)
    .then(user => user ? res.json(user) : res.status(400).json({ message: 'Username or password is incorrect' }))
    .catch(err => next(err));
}

function getAll(req, res, next) {
    userService.getAll()
        .then(users => res.json(users))
        .catch(err => next(err));
}


// const register = (req, res, next) =>{
//     bcrypt.hash(req.body.password, 10, function(err, hashpass){
//         if(err){
//             res.json({
//                 error: err
//             })
//         }
//     let user = new User({
//         firstname:req.body.firstname,
//         lastname: req.body.lastname,
//         email:req.body.email,
//         password: hashpass,
//         phone:req.body.phone,
//         address: req.body.address
//     })
//     user.save()
//     .then(response =>{
//         res.status(200).json({
//              message: "Successfully Register",
//              status:200
//         })
//     })
//     .catch(error =>{
//         res.status(400).json({
//             message:"Error Something went wrong!",
//         })
//     })
// })
// }

module.exports = {register, login, getAll }

