const User = require('../Model/User');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');


async function create(userParam) {
   if (await User.findOne({ email: userParam.email })) {
    return {
       message:"error"
    };
    }
   const user = new User(userParam);
    // hash password
    if (userParam.password) {
        user.hash = bcrypt.hash(userParam.password, 10);
    }
   // save user
    await user.save();
}

async function auth(userPara)
{
   const user = await User.findOne({email: userPara.email}, { "password": 0 });
       if(user &&  bcrypt.compare(user.password, userPara.password)){
        const token = jwt.sign({name:user._id}, 'Secret', {expiresIn:'1h'})
        return {
            ...user.toJSON(),
            token
        };
      }
      
}

async function getAll() {
    return await User.find();
}

module.exports = {create, auth, getAll};