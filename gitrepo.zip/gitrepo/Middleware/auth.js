const jwt = require('jsonwebtoken')
const  authenicate = (req, res, next) =>{
    try {
        const token = req.headers.authorization.slice(7)
        console.log(token)
        const decode = jwt.verify(token, 'secret', function(err, result){
            if(err)
            {
                console.log(err);
            }
            else
            {
               console.log(result);
            }
        })

        req.user = decode
        return next()
     }
    catch(error){
      res.json({
          message: "Authorization Failed!"
      })
    }
}
module.exports = authenicate;